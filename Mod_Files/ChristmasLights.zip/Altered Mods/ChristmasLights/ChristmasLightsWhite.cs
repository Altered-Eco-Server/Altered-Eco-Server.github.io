namespace Eco.Mods.TechTree
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using Eco.Core.Items;
    using Eco.Gameplay.Blocks;
    using Eco.Gameplay.Components;
    using Eco.Gameplay.Components.Auth;
    using Eco.Gameplay.DynamicValues;
    using Eco.Gameplay.Economy;
    using Eco.Gameplay.Housing;
    using Eco.Gameplay.Interactions;
    using Eco.Gameplay.Items;
    using Eco.Gameplay.Modules;
    using Eco.Gameplay.Minimap;
    using Eco.Gameplay.Objects;
    using Eco.Gameplay.Players;
    using Eco.Gameplay.Property;
    using Eco.Gameplay.Skills;
    using Eco.Gameplay.Systems.TextLinks;
    using Eco.Gameplay.Pipes.LiquidComponents;
    using Eco.Gameplay.Pipes.Gases;
    using Eco.Gameplay.Systems.Tooltip;
    using Eco.Shared;
    using Eco.Shared.Math;
    using Eco.Shared.Localization;
    using Eco.Shared.Serialization;
    using Eco.Shared.Utils;
    using Eco.Shared.View;
    using Eco.Shared.Items;
    using Eco.Gameplay.Pipes;
    using Eco.World.Blocks;
    using Eco.Gameplay.Housing.PropertyValues;

    [Serialized]
    [RequireComponent(typeof(PropertyAuthComponent))]
    //[RequireComponent(typeof(SolidGroundComponent))]
    public partial class ChristmasLightsObject : WorldObject, IRepresentsItem
    {
        public override LocString DisplayName { get { return Localizer.DoStr("Christmas Lights White"); } }
        public virtual Type RepresentedItemType { get { return typeof(ChristmasLightsItem); } }

        protected override void Initialize()
        {
            this.ModsPreInitialize();
            this.ModsPostInitialize();
        }

        public override void Destroy()
        {
            base.Destroy();
        }

        /// <summary>Hook for mods to customize WorldObject before initialization. You can change housing values here.</summary>
        partial void ModsPreInitialize();
        /// <summary>Hook for mods to customize WorldObject after initialization.</summary>
        partial void ModsPostInitialize();
    }

    [Serialized]
	[MaxStackSize(200)]
	[Solid]
    [LocDisplayName("Christmas Lights White")]
    public partial class ChristmasLightsItem : WorldObjectItem<ChristmasLightsObject>
    {
        public override LocString DisplayDescription => Localizer.DoStr("Christmas Lights White");


    }
	
    public partial class ChristmasLightsWhiteRecipe : RecipeFamily
    {
        public ChristmasLightsWhiteRecipe()
        {
            var recipe = new Recipe();
            recipe.Init(
                "ChristmasLightsWhite",  //noloc
                Localizer.DoStr("Christmas Lights White"),
                new List<IngredientElement>
                {
                    new IngredientElement(typeof(GlassItem), 1, true),
					new IngredientElement(typeof(SyntheticRubberItem), 1, true),					//noloc
					new IngredientElement(typeof(CopperBarItem), 1, true),
                },
                new List<CraftingElement>
                {
                    new CraftingElement<ChristmasLightsItem>(4)
                });
            this.Recipes = new List<Recipe> { recipe };
            this.ExperienceOnCraft = 1;
            this.LaborInCalories = CreateLaborInCaloriesValue(200);
            this.CraftMinutes = CreateCraftTimeValue(1);
            this.ModsPreInitialize();
            this.Initialize(Localizer.DoStr("Christmas Lights White"), typeof(ChristmasLightsWhiteRecipe));
            this.ModsPostInitialize();
            CraftingComponent.AddRecipe(typeof(WorkbenchObject), this);
        }

        /// <summary>Hook for mods to customize RecipeFamily before initialization. You can change recipes, xp, labor, time here.</summary>
        partial void ModsPreInitialize();
        /// <summary>Hook for mods to customize RecipeFamily after initialization, but before registration. You can change skill requirements here.</summary>
        partial void ModsPostInitialize();
    }
}

