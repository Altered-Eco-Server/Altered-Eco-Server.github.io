using System;
using System.Threading;
using Eco.Core.Plugins.Interfaces;
using Eco.Core.Utils;
using Eco.Simulation.Time;
using System.Linq;
using Eco.Shared.Math;
using Eco.Shared.Utils;
using Eco.Simulation;
using Eco.Simulation.Types;

namespace Eco.Mods.AlteredEco
{
    public class OldGrowthGenerator : IModKitPlugin, IInitializablePlugin
    {
        public Timer Timer;
        public static float DaysToMaturity = 15f; //How old a Redwood needs to be to change to an Old Growth Redwood

        public void Initialize(TimedTask timer)
        {

            Timer = new(Timer_tick, null, 60000, 60000);

        }

        static void Timer_tick(object state)
        {

            foreach (var plant in EcoSim.PlantSim.All)
            {
                if (plant.Species.Name.Equals("Redwood"))
                {
                    Vector3i pos = plant.Position.XYZi;
                    double bornTime = plant.BornTime;
                    var oldGrowth = EcoSim.AllSpecies.OfType<TreeSpecies>().First<TreeSpecies>((Func<TreeSpecies, bool>)(t => t.Name.Equals("OldGrowthRedwood")));
                    if (WorldTime.Seconds - bornTime > (double)DaysToMaturity * 86400)
                    {
                        plant.Destroy();
                        ThreadUtils.Delay(0.5f, (Action)(() => EcoSim.PlantSim.SpawnPlant(oldGrowth, pos).GrowthPercent = 1f));
                    }
                }
            }
        }

        public string GetStatus() => string.Empty;
    }
}